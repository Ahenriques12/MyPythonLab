#!/usr/bin/env python
# coding: utf-8

# In[3]:


# "Make your post Viral! : Exploring HackerNews Trending patterns\n"

## "Introduction \n"
# "In order to analyse the outcome of the most viral posts , we are gonna compare
#the type of the post and the time at wich it was posted to compare the better performance
#relative to the coments made per post"


# In[4]:


import csv
    


# In[ ]:





# In[ ]:





# In[5]:


with open("hacker_news.csv") as csv_file:
    csv_reader = csv.reader(csv_file)
    list_of_csv = list(csv_reader)
    hn = list_of_csv
   ## print(hn[:5])


# In[6]:


## Removing headers from a list of list
headers = hn[0]
del hn[0]
## print(headers)
## print(hn[:5])




# In[7]:


## Extracting Ask HN and Show HN Posts 
ask_posts = []
show_posts =[]
other_posts =[]

for row in hn:
    title = row[1]
    title = title.lower()
    if title.startswith("ask hn") == True:
        ask_posts.append(row)
    elif title.startswith("show hn") ==True:
        show_posts.append(row)
    else:
        other_posts.append(row)
        
## print(len(ask_posts))
## print(len(show_posts))
## print(len(other_posts))


# In[8]:


## Calculating the Average Number of Comments
## for Ask HN and Show HN Posts

total_ask_comments = 0

for row in ask_posts:
    num_of_comments = row[4]
    num_of_comments = int(num_of_comments)
    total_ask_comments += num_of_comments
    

avg_ask_comments = total_ask_comments / len(ask_posts)
print(avg_ask_comments)

total_show_comments = 0

for row in show_posts:
    num_of_comments = row[4]
    num_of_comments = int(num_of_comments)
    total_show_comments += num_of_comments
    

avg_show_comments = total_show_comments / len(show_posts)
print(avg_show_comments)

#as you can ask posts recive on average 14 comments per post,
# wich is more than the average of 10 shown in Show posts#


# In[9]:


## Finding the number of ask posts and comments by hour
import datetime as dt

result_list= []
for post in ask_posts:
    time_of_creation = post[6]
    num_of_comments = int(post[4])
    result_list.append([time_of_creation, num_of_comments])
       
# print(result_list[:3])   testing  #  
counts_by_hour = {}
comments_by_hour = {}
date_format = "%m/%d/%Y %H:%M"
for row in result_list:
    hour = row[0]
    comments = row[1]
    changed_hour = dt.datetime.strptime(hour, date_format ) #created a time object#
    converted_hour = changed_hour.strftime("%H")  
    if converted_hour not in counts_by_hour:
            counts_by_hour[converted_hour] = 1
            comments_by_hour[converted_hour] = comments
    else:
            counts_by_hour[converted_hour] += 1
            comments_by_hour[converted_hour] += comments
            
## print("Counts by hour:", counts_by_hour)
## print('\n')
## print("Comments by hour:", comments_by_hour)


# In[10]:


## Calculating the Average Number of Comments
## for Ask HN Posts by Hour
avg_by_hour = []


for hour in comments_by_hour:
    avg_by_hour.append([hour, int(comments_by_hour[hour]/ counts_by_hour[hour])])
    
#test print(avg_by_hour[:3]) #


# In[23]:


## Sorting and Printing Values from a List of Lists
swap_avg_by_hour = []

 for row in avg_by_hour:
    hour = row[0]
    avg = row[1]
    swap_avg_by_hour.append([avg, hour ])
    print(swap_avg_by_hour[:3])
sorted_swap = sorted(swap_avg_by_hour, reverse = True
print("Top 5 most commented posts")
                     
for element in sorted_swap[:6]:
    time = element[1]
    avg = [row[0]]
    hour = dt.datetime.strptime(time, "%H").strftime("%H:00")
    template = "{t}: {a:.2f} average comments per post"
    output = template.format(t = hour , a = avg )
    print(output)
    


# In[12]:


##CONCLUSION
## In this project, we analyzed survey data from
##HackerNews posts to find the best time to post
##in order to get more engagement. 
##The conclusion we reached is that according to the top 5 results, the best
##time to create a post is */


# In[ ]:





# In[ ]:




